"use strict";

const RULESET_ID = "ruleset_1";
const toggle = document.getElementById("toggle");
const count = document.getElementById("count");
const countLabel = document.getElementById("count-label");
const reportButton = document.getElementById("report");
const message = document.getElementById("message");

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

async function broadcastEnabled(enabled) {
  const tabs = await chrome.tabs.query({});
  await Promise.allSettled(
    tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) =>
      chrome.tabs.sendMessage(tab.id, { type: "CPAB_SET_ENABLED", enabled })
    )
  );
}

async function setRulesetEnabled(enabled) {
  const activeRulesets = await chrome.declarativeNetRequest.getEnabledRulesets();
  const isCurrentlyEnabled = activeRulesets.includes(RULESET_ID);
  if (enabled && !isCurrentlyEnabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: [RULESET_ID] });
  } else if (!enabled && isCurrentlyEnabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: [RULESET_ID] });
  }
}

async function updateCount() {
  const tab = await getActiveTab();
  if (!tab || !Number.isInteger(tab.id) || !/^https?:/i.test(tab.url || "")) {
    count.textContent = "—";
    countLabel.textContent = "Không khả dụng trên trang này";
    return;
  }

  try {
    const state = await chrome.tabs.sendMessage(tab.id, { type: "CPAB_GET_STATE" });
    count.textContent = String(state?.hiddenCount ?? 0);
    countLabel.textContent = "Khung quảng cáo trống đã ẩn trên trang này";
  } catch (_) {
    count.textContent = "—";
    countLabel.textContent = "Chưa đọc được dữ liệu trang này";
    showMessage("Nếu trang đã mở trước khi cài tiện ích, hãy tải lại trang.");
  }
}

async function initialise() {
  toggle.disabled = true;
  try {
    const settings = await chrome.storage.local.get({ enabled: true });
    const enabled = settings.enabled !== false;
    await setRulesetEnabled(enabled);
    toggle.checked = enabled;
    await chrome.storage.local.set({ enabled });
    await broadcastEnabled(enabled);
    await updateCount();
  } catch (error) {
    showMessage(`Không thể khởi tạo: ${error?.message || "lỗi không xác định"}`, true);
  } finally {
    toggle.disabled = false;
  }
}

toggle.addEventListener("change", async () => {
  const requestedEnabled = toggle.checked;
  toggle.disabled = true;
  showMessage("Đang cập nhật trạng thái…");

  try {
    await setRulesetEnabled(requestedEnabled);
    await chrome.storage.local.set({ enabled: requestedEnabled });
    await broadcastEnabled(requestedEnabled);
    showMessage(requestedEnabled ? "Đã bật chặn quảng cáo." : "Đã tắt chặn quảng cáo.");
    await updateCount();
  } catch (error) {
    toggle.checked = !requestedEnabled;
    showMessage(`Không đổi được trạng thái: ${error?.message || "lỗi không xác định"}`, true);
  } finally {
    toggle.disabled = false;
  }
});

reportButton.addEventListener("click", async () => {
  try {
    const tab = await getActiveTab();
    if (!tab || !/^https?:/i.test(tab.url || "")) {
      showMessage("Không lấy được địa chỉ của trang hiện tại.", true);
      return;
    }
    const reportText = `${tab.title || "Quảng cáo bị bỏ sót"}\n${tab.url}`;
    await navigator.clipboard.writeText(reportText);
    showMessage("Đã sao chép tiêu đề và URL trang. Dán chúng vào nơi gửi báo cáo.");
  } catch (error) {
    showMessage(`Không sao chép được URL: ${error?.message || "lỗi clipboard"}`, true);
  }
});

// Refresh the current-page count when the popup becomes visible.
initialise();
