(() => {
  "use strict";

  if (window.__chromeProAdBlockerContentLoaded) return;
  window.__chromeProAdBlockerContentLoaded = true;

  const HIDDEN_ATTR = "data-cpab-hidden";
  const ORIGINAL_DISPLAY_ATTR = "data-cpab-original-display";

  // Mở rộng danh sách bộ chọn nhắm đến các khung quảng cáo phổ biến tại Việt Nam và quốc tế
  const AD_SELECTORS = [
    ".ads", ".ad", ".advert", ".advertisement", ".banner-ads", ".ads-container",
    ".ad-container", ".ad-wrapper", ".ad-slot", ".ad-banner", ".adsbygoogle",
    "[class*='advert']", "[class*='banner-ads']", "[class*='ads-']", "[id*='div-gpt-ad']",
    "[id*='google_ads_iframe']", "[class*='box-ads']", "[id*='ad-slot']",
    "iframe[src*='ads']", "iframe[src*='doubleclick']"
  ].join(",");

  let enabled = false;
  let observer = null;
  let scanTimer = null;
  const pendingNodes = new Set();

  function hideElement(element) {
    if (!enabled || !(element instanceof Element) || !element.isConnected) return;
    if (element.hasAttribute(HIDDEN_ATTR)) return;

    // Lưu lại trạng thái display cũ để có thể khôi phục khi tắt extension
    element.setAttribute(ORIGINAL_DISPLAY_ATTR, element.style.getPropertyValue("display"));
    element.setAttribute(HIDDEN_ATTR, "1");
    element.style.setProperty("display", "none", "important");
  }

  function scanAndHide() {
    if (!enabled || !document.documentElement) return;
    const elements = document.querySelectorAll(AD_SELECTORS);
    for (const el of elements) {
      // Nếu là khung quảng cáo rõ rệt, ẩn thẳng tay
      hideElement(el);
    }
  }

  function processQueue() {
    scanTimer = null;
    if (!enabled) {
      pendingNodes.clear();
      return;
    }
    const nodes = [...pendingNodes];
    pendingNodes.clear();

    for (const node of nodes) {
      if (!(node instanceof Element) || !node.isConnected) continue;
      if (node.matches(AD_SELECTORS)) {
        hideElement(node);
      }
      const children = node.querySelectorAll(AD_SELECTORS);
      for (const child of children) {
        hideElement(child);
      }
    }
  }

  function queueNode(node) {
    if (!node) return;
    const element = node instanceof Element ? node : node.parentElement;
    if (!element) return;
    pendingNodes.add(element);

    if (!scanTimer) {
      scanTimer = setTimeout(processQueue, 150);
    }
  }

  function startObserver() {
    if (observer || !document.documentElement) return;
    observer = new MutationObserver((records) => {
      for (const record of records) {
        if (record.type === "childList") {
          for (const node of record.addedNodes) {
            queueNode(node);
          }
        }
      }
    });
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true
    });
  }

  function restoreAll() {
    if (scanTimer) {
      clearTimeout(scanTimer);
      scanTimer = null;
    }
    pendingNodes.clear();

    const hiddenElements = document.querySelectorAll(`[${HIDDEN_ATTR}="1"]`);
    for (const el of hiddenElements) {
      const originalDisplay = el.getAttribute(ORIGINAL_DISPLAY_ATTR) || "";
      if (originalDisplay) {
        el.style.setProperty("display", originalDisplay);
      } else {
        el.style.removeProperty("display");
      }
      el.removeAttribute(HIDDEN_ATTR);
      el.removeAttribute(ORIGINAL_DISPLAY_ATTR);
    }
  }

  function applyEnabled(nextEnabled) {
    enabled = Boolean(nextEnabled);
    if (enabled) {
      startObserver();
      scanAndHide();
    } else {
      if (observer) {
        observer.disconnect();
        observer = null;
      }
      restoreAll();
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message.type !== "string") return false;

    if (message.type === "CPAB_SET_ENABLED") {
      applyEnabled(message.enabled);
      sendResponse({ ok: true, enabled });
      return false;
    }
    if (message.type === "CPAB_GET_STATE") {
      const hiddenCount = document.querySelectorAll(`[${HIDDEN_ATTR}="1"]`).length;
      sendResponse({ enabled, hiddenCount });
      return false;
    }
    return false;
  });

  chrome.storage.local.get({ enabled: true }, (settings) => {
    applyEnabled(settings.enabled !== false);
  });
})();