Chrome Pro Ad Blocker (Manifest V3)

Files:
- manifest.json : extension configuration, static DNR ruleset, content script and permissions
- rules.json    : 20 static declarativeNetRequest block rules
- content.js    : hides likely ad containers only when their visible content appears empty;
                  batches DOM changes with MutationObserver to limit repeated scans
- popup.html    : popup UI
- popup.css     : popup styling
- popup.js      : toggle, per-page cosmetic count, and copy-page-URL report helper
- logo.png      : generated no-ads logo used in the popup
- icons/        : 16, 32, 48 and 128 px icons used by Chrome

Install in Chrome:
1. Extract this folder to a permanent location.
2. Open chrome://extensions/.
3. Turn on Developer mode.
4. Click Load unpacked and select the chrome-pro-ad-blocker folder.
5. Reload any web tabs that were already open before installation.

Notes:
- The popup counter shows empty ad-like elements hidden on the current page, not the
  total number of network requests blocked. A reliable network-block counter would
  require additional DNR feedback capabilities and permissions.
- Chrome internal pages and the Chrome Web Store do not allow ordinary content scripts.
- This is a domain-list starter filter, not a guarantee of blocking every ad or pop-up.
